import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Login from "./components/Login";
import Otp from "./components/Otp";
import Success from "./components/Success";
import "./App.css";

const App = () => (
  <Router>
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/otp" element={<Otp />} />
      <Route path="/success" element={<Success />} />
    </Routes>
  </Router>
);
export default App;
