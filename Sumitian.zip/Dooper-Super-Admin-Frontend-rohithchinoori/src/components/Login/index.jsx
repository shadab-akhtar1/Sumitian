import { Link } from "react-router-dom";

const Login = () => (
  <div className="flex flex-row h-screen">
    <div className="bg-[#B60336] w-1/3 h-243 my-3 ml-5 pl-5 flex flex-col justify-between rounded-lg">
      <p className="text-white mt-5">DOOPER</p>
      <div>
        <h1 className="text-white text-4xl w-61">Start your journey with us</h1>
        <p className="text-white w-3/6 pt-2 text-xl">
          Discover the world’s best community of doctors and DHAs
        </p>
      </div>
      <div className="bg-white p-3 w-2/3 mb-5 rounded-lg ">
        <p className="w-45">
          Simply unbelievable! I am really satisfied with the doctor who treated
          me. This is absolutely wonderful!
        </p>
        <div className="flex">
          <img
            src="https://res.cloudinary.com/dsyljcxpu/image/upload/v1701954493/Rectangle_618_uv0gaw.png"
            alt="review"
            className="h-10 w-10 mt-4"
          />
          <div className="p-3">
            <p>Timson K</p>
            <img
              src="https://res.cloudinary.com/dsyljcxpu/image/upload/v1702015095/stars_iwl9be.png"
              alt="stars"
            />
          </div>
        </div>
      </div>
    </div>
    <div className="w-2/3 flex flex-col items-center justify-between ">
      <img
        src="https://res.cloudinary.com/dsyljcxpu/image/upload/v1702018869/Dooper_Logo_1500x1500_2_a1lchd.png"
        alt="dooper-logo"
        className="mt-5"
      />
      <div className="flex flex-col items-center p-5">
        <h1 className="text-4xl font-monos font-semibold p-5">Welcome</h1>
        <p>
          Welcome to{" "}
          <span className="text-[#E40443] font-semibold">DOOPER</span>, please
          enter your details
        </p>
        <div className="flex flex-col justify-start mr-30 mt-5">
          <label>Phone Number</label>
          <div className="flex items-center w-96 h-12  pt-5 border-solid border-2 p-3 border-grey-50">
            <img
              src="https://res.cloudinary.com/dsyljcxpu/image/upload/v1702023747/image_1_tc7wsh.png"
              alt="flag"
              className="h-6 w-6 mr-2"
            />
            <input
              type="tel"
              placeholder="Enter your phone number"
              className="ml-2"
            />
          </div>
          <Link
            to="/otp"
            className="mt-4 text-white text-center bg-[#E40443] h-10"
          >
            <button>Send OTP</button>
          </Link>
        </div>
      </div>
      <div className="flex flex-col items-center">
        <div className="flex items-center mr-12">
          <input type="checkbox" className="h-10" id="check" />
          <label className="ml-3" htmlFor="check">
            By signing up you agree to{" "}
            <span className="text-[#E40443] font-semibold">Terms of use</span>
          </label>
        </div>
        <div className="flex items-center pt-4">
          <input type="checkbox" id="check1" />
          <label className="ml-3" htmlFor="check1">
            By signing up you agree to{" "}
            <span className="text-[#E40443] font-semibold">
              Marketing condition
            </span>
          </label>
        </div>
      </div>
      <p className="w-10/12  pb-5">
        Join the community of smart and experienced doctors. Login to access
        your personalized dashboard, track your record or process and get
        informed by our services
      </p>
    </div>
  </div>
);

export default Login;
