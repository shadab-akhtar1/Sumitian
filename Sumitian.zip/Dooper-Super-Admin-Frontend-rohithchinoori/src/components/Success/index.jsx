const Success = () => (
  <div className="flex flex-row h-screen">
    <div className="bg-[#B60336] w-1/3 h-243 my-3 ml-5 pl-5 flex flex-col justify-between rounded-lg">
      <p className="text-white mt-5">DOOPER</p>
      <div>
        <h1 className="text-white text-4xl w-61">Start your journey with us</h1>
        <p className="text-white w-3/6 pt-2 text-xl">
          Discover the world’s best community of doctors and DHAs
        </p>
      </div>
      <div className="bg-white p-3 w-2/3 mb-5 rounded-lg ">
        <p className="w-45">
          Simply unbelievable! I am really satisfied with the doctor who treated
          me. This is absolutely wonderful!
        </p>
        <div className="flex">
          <img
            src="https://res.cloudinary.com/dsyljcxpu/image/upload/v1701954493/Rectangle_618_uv0gaw.png"
            alt="review"
            className="h-10 w-10 mt-4"
          />
          <div className="p-3">
            <p>Timson K</p>
            <img
              src="https://res.cloudinary.com/dsyljcxpu/image/upload/v1702015095/stars_iwl9be.png"
              alt="stars"
            />
          </div>
        </div>
      </div>
    </div>
    <div className="w-2/3 flex flex-col items-center justify-between ">
      <img
        src="https://res.cloudinary.com/dsyljcxpu/image/upload/v1702018869/Dooper_Logo_1500x1500_2_a1lchd.png"
        alt="dooper-logo"
        className="mt-5"
      />
      <div className="flex flex-col items-center p-5">
        <img
          src="https://res.cloudinary.com/dsyljcxpu/image/upload/v1702031585/Screenshot_5_gdnjw1.png"
          alt="suc"
          className="h-40"
        />
        <h1 className="text-2xl font-bold">Successful</h1>
        <p>OPT Is verified successfully</p>
        <button className="bg-[#FCE6EC] text-red-600 font-bold p-2 w-40 mt-5">
          Continue
        </button>
      </div>
      <p className="w-10/12  pb-5">
        Join the community of smart and experienced doctors. Login to access
        your personalized dashboard, track your record or process and get
        informed by our services
      </p>
    </div>
  </div>
);

export default Success;
