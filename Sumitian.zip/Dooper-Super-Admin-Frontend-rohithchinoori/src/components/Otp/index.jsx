import { Component, createRef } from "react";
import { Link } from "react-router-dom";

class Otp extends Component {
  constructor(props) {
    super(props);

    // Create an array of refs for each input element
    this.inputRefs = Array(4)
      .fill(null)
      .map(() => createRef());
  }

  handleInputChange = (index, value) => {
    // Move focus to the next input box if a digit is entered
    if (index < 3 && value !== "") {
      this.inputRefs[index + 1].current.focus();
    }
  };
  render() {
    return (
      <div className="flex flex-row h-screen">
        <div className="bg-[#B60336] w-1/3 h-243 my-3 ml-5 pl-5 flex flex-col justify-between rounded-lg">
          <p className="text-white mt-5">DOOPER</p>
          <div>
            <h1 className="text-white text-4xl w-61">
              Start your journey with us
            </h1>
            <p className="text-white w-3/6 pt-2 text-xl">
              Discover the world’s best community of doctors and DHAs
            </p>
          </div>
          <div className="bg-white p-3 w-2/3 mb-5 rounded-lg ">
            <p className="w-45">
              Simply unbelievable! I am really satisfied with the doctor who
              treated me. This is absolutely wonderful!
            </p>
            <div className="flex">
              <img
                src="https://res.cloudinary.com/dsyljcxpu/image/upload/v1701954493/Rectangle_618_uv0gaw.png"
                alt="review"
                className="h-10 w-10 mt-4"
              />
              <div className="p-3">
                <p>Timson K</p>
                <img
                  src="https://res.cloudinary.com/dsyljcxpu/image/upload/v1702015095/stars_iwl9be.png"
                  alt="stars"
                />
              </div>
            </div>
          </div>
        </div>
        <div className="w-2/3 flex flex-col items-center justify-between ">
          <img
            src="https://res.cloudinary.com/dsyljcxpu/image/upload/v1702018869/Dooper_Logo_1500x1500_2_a1lchd.png"
            alt="dooper-logo"
            className="mt-5"
          />
          <div className="flex flex-col items-center p-5">
            <h1 className="text-4xl font-monos font-semibold p-5">Verify</h1>
            <p>Enter OTP which we sent to you</p>
            <div className="flex items-center mr-3">
              {[0, 1, 2, 3].map((index) => (
                <input
                  key={index}
                  type="text"
                  maxLength="1"
                  inputMode="numeric"
                  id={`number-${index}`}
                  className="h-12 w-12 text-2xl m-3 border border-gray-400 rounded"
                  ref={this.inputRefs[index]}
                  onChange={(e) =>
                    this.handleInputChange(index, e.target.value)
                  }
                />
              ))}
            </div>
            <Link
              to="/success"
              className="mt-4 text-white text-center bg-[#E40443] h-10 w-40"
            >
              <button>Verify OTP</button>
            </Link>
          </div>
          <p className="w-10/12  pb-5">
            Join the community of smart and experienced doctors. Login to access
            your personalized dashboard, track your record or process and get
            informed by our services
          </p>
        </div>
      </div>
    );
  }
}

export default Otp;
